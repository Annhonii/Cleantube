#!/usr/bin/env python3
"""Adds Background play + Popup (PiP) to CleanTube.
Run from the repo root:  python3 apply_patch.py
Needs BackgroundPlay.kt next to this script."""
import os, shutil, sys

root = os.getcwd()
here = os.path.dirname(os.path.abspath(__file__))
base = os.path.join(root, "app/src/main/java/com/cleantube/app")

def edit(path, pairs):
    with open(path, encoding="utf-8") as f:
        s = f.read()
    for old, new in pairs:
        if s.count(old) != 1:
            sys.exit("STOP: expected text not found exactly once in %s:\n%s" % (path, old[:120]))
        s = s.replace(old, new)
    with open(path, "w", encoding="utf-8") as f:
        f.write(s)
    print("patched", os.path.relpath(path, root))

# ---- new file
dst = os.path.join(base, "data/BackgroundPlay.kt")
shutil.copyfile(os.path.join(here, "BackgroundPlay.kt"), dst)
print("added", os.path.relpath(dst, root))

# ---- Player.kt
edit(os.path.join(base, "ui/Player.kt"), [
("val LocalFullscreen = staticCompositionLocalOf",
'''/** Lets other screens read / control the embedded player (used by "Background" to carry on from the same second). */
object PlayerControl {
    @Volatile var second: Float = 0f
    var owner: Any? = null
    var pause: (() -> Unit)? = null
}

/** Picture-in-picture ("Popup") state. The activity sets [enter] and flips [active]. */
object PipHost {
    var active by mutableStateOf(false)
    var enter: (() -> Unit)? = null
}

val LocalFullscreen = staticCompositionLocalOf'''),
('''            override fun onReady(youTubePlayer: YouTubePlayer) {
                player = youTubePlayer
            }
''','''            override fun onReady(youTubePlayer: YouTubePlayer) {
                player = youTubePlayer
                PlayerControl.owner = playerView
                PlayerControl.pause = { youTubePlayer.pause() }
            }

            override fun onCurrentSecond(youTubePlayer: YouTubePlayer, second: Float) {
                PlayerControl.second = second
            }
'''),
('''        onDispose {
            owner?.lifecycle?.removeObserver(playerView)
            player = null
''','''        onDispose {
            if (PlayerControl.owner === playerView) {
                PlayerControl.owner = null
                PlayerControl.pause = null
            }
            owner?.lifecycle?.removeObserver(playerView)
            player = null
'''),
('''    LaunchedEffect(player, videoId) {
        player?.loadVideo(videoId, 0f)''','''    LaunchedEffect(player, videoId) {
        PlayerControl.second = 0f
        player?.loadVideo(videoId, 0f)'''),
("Box(modifier.aspectRatio(16f / 9f).background(Color.Black)) {",
 "Box((if (PipHost.active) modifier.fillMaxSize() else modifier.aspectRatio(16f / 9f)).background(Color.Black)) {"),
])

# ---- VideoScreen.kt
edit(os.path.join(base, "ui/VideoScreen.kt"), [
("import androidx.compose.material.icons.rounded.Download\n",
 "import androidx.compose.material.icons.rounded.Download\nimport androidx.compose.material.icons.rounded.Headphones\nimport androidx.compose.material.icons.rounded.PictureInPictureAlt\n"),
("import com.cleantube.app.data.Api\n",
 "import com.cleantube.app.data.Api\nimport com.cleantube.app.data.BackgroundPlay\nimport com.cleantube.app.data.Streams\n"),
("    // Opening a video counts as watching it",
'''    // Background play: the sound keeps going with the screen off (see BackgroundPlay).
    var bgLoading by remember(route.id) { mutableStateOf(false) }
    fun toggleBackground() {
        if (BackgroundPlay.activeId == route.id) {
            BackgroundPlay.stop(ctx)
            return
        }
        if (bgLoading) return
        bgLoading = true
        Toast.makeText(ctx, "Starting background play…", Toast.LENGTH_SHORT).show()
        scope.launch {
            try {
                val audio = Streams.fetch(route.id).options.filter { it.audioOnly }
                val pick = audio.firstOrNull { it.ext == "m4a" } ?: audio.firstOrNull()
                    ?: throw ApiException(ApiException.Kind.OTHER, "No audio stream found for this video.")
                val startMs = (PlayerControl.second * 1000).toLong()
                PlayerControl.pause?.invoke()
                BackgroundPlay.start(ctx, route.id, video?.title.orEmpty(), pick.url, pick.userAgent, startMs)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Toast.makeText(ctx, "Couldn't start background play: ${e.message ?: "unknown error"}", Toast.LENGTH_LONG).show()
            } finally {
                bgLoading = false
            }
        }
    }

    // Opening a video counts as watching it'''),
('''    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        // rounded player "card"
        PlayerBox(
            videoId = route.id,
            embeddable = details?.embeddable ?: true,
            modifier = Modifier
                .padding(horizontal = 8.dp, vertical = 6.dp)
                .clip(RoundedCornerShape(24.dp))
        )

        Box(Modifier.fillMaxSize()) {''',
'''    val inPopup = PipHost.active
    Column(if (inPopup) Modifier.fillMaxSize() else Modifier.fillMaxSize().statusBarsPadding()) {
        // rounded player "card"
        PlayerBox(
            videoId = route.id,
            embeddable = details?.embeddable ?: true,
            modifier = if (inPopup) Modifier else Modifier
                .padding(horizontal = 8.dp, vertical = 6.dp)
                .clip(RoundedCornerShape(24.dp))
        )

        // everything below the player is hidden while the video is in the popup window
        if (!inPopup) Box(Modifier.fillMaxSize()) {'''),
('''                        ActionChip("YouTube", Icons.Rounded.PlayArrow, onClick = { openInYouTube(ctx, route.id) })
''','''                        val bgOn = BackgroundPlay.activeId == route.id
                        ActionChip(
                            "Background",
                            Icons.Rounded.Headphones,
                            onClick = { if (video != null) toggleBackground() },
                            container = if (bgOn) TextPrimary else Card,
                            content = if (bgOn) Bg else TextPrimary
                        )
                        ActionChip("Popup", Icons.Rounded.PictureInPictureAlt, onClick = { PipHost.enter?.invoke() })
'''),
])

# ---- MainActivity.kt
edit(os.path.join(base, "MainActivity.kt"), [
("import android.content.Intent\n",
 "import android.app.PictureInPictureParams\nimport android.content.Intent\n"),
("import android.os.Bundle\n",
 "import android.os.Bundle\nimport android.util.Rational\nimport android.widget.Toast\n"),
("import com.cleantube.app.ui.Nav\n",
 "import com.cleantube.app.ui.Nav\nimport com.cleantube.app.ui.PipHost\n"),
("        fullscreen.onChanged = { on -> applyFullscreen(on) }\n",
'''        fullscreen.onChanged = { on -> applyFullscreen(on) }

        // "Popup" button: shrink the video into a floating picture-in-picture window.
        PipHost.enter = { enterPopup() }
        addOnPictureInPictureModeChangedListener { info -> PipHost.active = info.isInPictureInPictureMode }
'''),
("    private fun applyFullscreen(on: Boolean) {",
'''    override fun onResume() {
        super.onResume()
        // safety net: never stay stuck in the "player only" layout after the popup window is gone
        PipHost.active = Build.VERSION.SDK_INT >= 24 && isInPictureInPictureMode
    }

    override fun onDestroy() {
        PipHost.enter = null
        PipHost.active = false
        super.onDestroy()
    }

    private fun enterPopup() {
        if (Build.VERSION.SDK_INT < 26 || !packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)) {
            Toast.makeText(this, "Popup isn't supported on this phone.", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build())
        } catch (e: Exception) {
            Toast.makeText(this, "Couldn't open the popup window.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun applyFullscreen(on: Boolean) {'''),
])

# ---- AndroidManifest.xml
edit(os.path.join(root, "app/src/main/AndroidManifest.xml"), [
('    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />\n',
 '''    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />
    <uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />
'''),
('            android:launchMode="singleTask"\n',
 '            android:launchMode="singleTask"\n            android:supportsPictureInPicture="true"\n'),
('''            android:foregroundServiceType="dataSync" />
''','''            android:foregroundServiceType="dataSync" />

        <service
            android:name=".data.BackgroundPlayService"
            android:exported="false"
            android:foregroundServiceType="mediaPlayback" />
'''),
])
print("\nDone. Now: git add . && git commit -m 'Add background play and popup' && git push")
